import telebot
import os

# Get Bot Token from environment
TOKEN = os.getenv("BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "សួស្តី! Bot Topup ដំណើរការ!")

bot.infinity_polling()
